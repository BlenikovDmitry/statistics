summa = 100000
sum_elems = 13